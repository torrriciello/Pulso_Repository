import pandas as pd
import json
import os
import time
from azure.servicebus import ServiceBusClient, ServiceBusMessage

CONNECTION_STR = os.environ.get("SERVICEBUS_CONNECTION_STR")
if not CONNECTION_STR:
    import getpass
    print("Cole a connection string do Service Bus (não será exibida na tela):")
    CONNECTION_STR = getpass.getpass()

QUEUE_NAME = "incidentes"

# Quantos incidentes reais mandar (amostra, não o dataset inteiro)
QUANTIDADE_A_ENVIAR = 10

print("=" * 60)
print("[PULSO] SIMULADOR DE PULSAÇÃO - Enviando incidentes reais")
print("=" * 60)

# 1. Carrega o dataset real
df = pd.read_csv('../01_dataset/LW-DATASET.csv', sep=',', encoding='utf-8-sig', on_bad_lines='skip')
print(f"[*] Dataset carregado: {len(df):,} incidentes totais")

# 2. Pega uma amostra aleatória (pra ter variedade de prioridades e situações)
amostra = df.sample(n=min(QUANTIDADE_A_ENVIAR, len(df)), random_state=42)
print(f"[*] Amostra selecionada: {len(amostra)} incidentes")

# 3. Conecta na fila
servicebus_client = ServiceBusClient.from_connection_string(conn_str=CONNECTION_STR)

enviados = 0
erros = 0

with servicebus_client:
    sender = servicebus_client.get_queue_sender(queue_name=QUEUE_NAME)
    with sender:
        for _, linha in amostra.iterrows():
            try:
                # Trata valores nulos/NaN antes de montar o JSON
                incidente_pai = linha['Incidente Pai']
                incidente_pai = None if pd.isna(incidente_pai) else str(incidente_pai)

                duracao_segundos = int(linha['Duração']) if pd.notna(linha['Duração']) else 0
                incidente = {
                    "numero": str(linha['Número']),
                    "aberto_por": str(linha['Aberto por']) if pd.notna(linha['Aberto por']) else "Desconhecido",
                    "status": str(linha['Status']) if pd.notna(linha['Status']) else "Desconhecido",
                    "incidente_pai": incidente_pai,
                    "prioridade": str(linha['Prioridade']) if pd.notna(linha['Prioridade']) else "N/A",
                    "duracao_segundos": duracao_segundos
                }

                corpo = json.dumps(incidente, ensure_ascii=False)
                mensagem = ServiceBusMessage(corpo)
                sender.send_messages(mensagem)
                enviados += 1

                if enviados % 10 == 0:
                    print(f"[*] {enviados}/{len(amostra)} enviados...")

            except Exception as e:
                erros += 1
                print(f"[ERRO] Falha ao enviar incidente {linha.get('Número', '?')}: {e}")

print("=" * 60)
print(f"[OK] Envio concluído: {enviados} enviados, {erros} erros")
print("=" * 60)
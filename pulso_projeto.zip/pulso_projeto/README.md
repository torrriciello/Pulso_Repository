# PULSO — AIOps para Previsão de Incidentes e Tendências Operacionais

**Challenge Locaweb + FIAP 2026 | Equipe Fluxo | Turma 2TSCOA**

Solução de AIOps que processa incidentes reais da Locaweb em um pipeline serverless na Azure, prevendo volume de incidentes, identificando causas recorrentes, explicando fatores de risco de violação de SLA e projetando o atingimento de metas anuais de OLA.

## O que a solução faz

- **Ingestão real:** incidentes são enviados via Azure Service Bus, processados por uma Azure Function orientada a eventos
- **Regras de negócio automatizadas:** filtro de ruído operacional, deduplicação de incidentes-pai, elegibilidade ao cálculo de KPI
- **Alertas preventivos:** quando um incidente atinge 85% do tempo de SLA, um Adaptive Card é disparado via webhook em tempo real
- **Analytics avançado:** previsão de volume por prioridade (D+1/D+7), clusterização de causas recorrentes, explicabilidade do risco de SLA, e simulação de atingimento de metas anuais
- **Dashboard:** Power BI consumindo dados diretamente do Azure Blob Storage (dados brutos + análises agregadas)

## Arquitetura

```
Dataset histórico (LW-DATASET)
        │
        ▼
  Azure Service Bus (fila "incidentes")
        │
        ▼
  Azure Function (Consumo Flexível)
   ├─ Filtra ruído operacional
   ├─ Valida elegibilidade ao KPI
   └─ Dispara alerta se risco de SLA ≥ 85%
        │
        ├──────────────┬──────────────────┐
        ▼              ▼                  ▼
  Blob Storage:   Blob Storage:      Webhook
incidentes-      alertas-teams      (Adaptive Card)
processados
        │              
        ▼              
  Blob Storage: kpi-agregados
  (previsões, clusters, explicabilidade,
   projeção de metas — gerados via notebook)
        │
        ▼
     Power BI
```

## Estrutura do repositório

```
01_dataset/           → dataset histórico oficial da Locaweb
02_codigo/             → notebooks e scripts (Function, simulador, análises)
03_evidencias/         → prints de evidência de funcionamento real
04_powerbi_export/     → CSVs agregados consumidos pelo Power BI


## Tecnologias

| Componente | Tecnologia |
|---|---|
| Ingestão | Azure Service Bus (fila) |
| Processamento | Azure Functions (Python, Consumo Flexível) |
| Persistência | Azure Blob Storage (Data Lake não relacional — JSON + CSV) |
| Alertas | Webhook HTTP → Adaptive Card |
| Análises | Python (pandas, scikit-learn: RandomForest, KMeans, TF-IDF) |
| Visualização | Power BI Desktop/Service |

## Como rodar localmente

```bash
cd 02_codigo
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
```

Copie `local.settings.example.json` para `local.settings.json` e preencha com suas próprias credenciais do Azure (Service Bus e Blob Storage). **Nunca commite esse arquivo com credenciais reais.**

Para reproduzir as análises e reenviar os agregados para o Power BI:

```bash
jupyter notebook PULSO_ANALYTICS_POWERBI.ipynb
```

## Principais resultados

- **80.341 incidentes (65,6%)** identificados como ruído operacional e descartados do cálculo de KPI
- **Meta anual de OLA para P2-Alta já ultrapassada em 2025:** 42 violações contra teto de 31 (135% da meta) — apenas 19,4% de chance de fechar o próximo ano dentro da meta, mantido o ritmo atual
- **Modelo de previsão de volume** com WAPE de 13,4% (total) — usado para antecipar D+1 e D+7
- **6 clusters de causas recorrentes** identificados via TF-IDF + KMeans sobre descrições de incidentes
- **Modelo de risco de SLA** com AUC de 0,79.
